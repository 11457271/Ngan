
let score = 0;
let answered = {};
function clearActive(){document.querySelectorAll("section").forEach(s=>s.classList.remove("active"))}
function showCover(){clearActive();document.getElementById("cover").classList.add("active");window.scrollTo(0,0)}
function goTo(n){clearActive();document.getElementById("day"+n).classList.add("active");window.scrollTo(0,0)}
function answer(btn, correct){
    let section = btn.closest("section").id;
    if(answered[section]) return;
    answered[section] = true;
    let buttons = btn.parentElement.querySelectorAll(".option");
    buttons.forEach(b=>b.disabled=true);
    if(correct){
        btn.classList.add("correct");
        score += 10;
        document.getElementById("score").innerText = score;
    }else{
        btn.classList.add("wrong");
        buttons.forEach(b=>{if(b.getAttribute("onclick").includes("true")) b.classList.add("correct")});
    }
    btn.closest(".day-card").querySelector(".next").disabled = false;
}
function finish(){
    clearActive();
    document.getElementById("end").classList.add("active");
    document.getElementById("finalScore").innerText = score;
    let comment = "";
    if(score >= 60){comment = "太棒了！你獲得「胡志明市旅遊達人」稱號！"}
    else if(score >= 40){comment = "不錯！你完成了旅程，也認識了很多胡志明市的景點。"}
    else{comment = "沒關係！你可以再挑戰一次，重新認識胡志明市。"}
    document.getElementById("comment").innerText = comment;
}
